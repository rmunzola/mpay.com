/* ═══════════════════════════════════════════
   MMSG v2 — app.js
   Logique complète + Paramètres société + Logo
═══════════════════════════════════════════ */
'use strict';

// ──────────────────────────────────────────
// BASE DE DONNÉES (LocalStorage)
// ──────────────────────────────────────────
const DB = {
  get(k) { try { return JSON.parse(localStorage.getItem('mmsg2_' + k)) || []; } catch { return []; } },
  set(k, v) { localStorage.setItem('mmsg2_' + k, JSON.stringify(v)); },
  getObj(k, d = {}) { try { return JSON.parse(localStorage.getItem('mmsg2_' + k)) || d; } catch { return d; } },
  setObj(k, v) { localStorage.setItem('mmsg2_' + k, JSON.stringify(v)); }
};

// ──────────────────────────────────────────
// CONFIGURATION SOCIÉTÉ
// ──────────────────────────────────────────
let CFG = DB.getObj('config', {
  nom: 'Mobile Marketing Solutions Group',
  sigle: 'MMSG', secteur: '', rccm: '', nif: '',
  adresse: '', ville: '', pays: 'République Démocratique du Congo',
  tel1: '', tel2: '', email: '', web: '',
  devise: '$', tva: 16, prefFact: 'FA', prefDevis: 'DV', delai: 30,
  mention: '',
  banque: '', titulaire: '', compte: '', swift: '', momo: '',
  logo: '' // base64
});

// ──────────────────────────────────────────
// UTILISATEUR CONNECTÉ
// ──────────────────────────────────────────
let CU = null; // current user

// ──────────────────────────────────────────
// INIT UTILISATEURS PAR DÉFAUT
// ──────────────────────────────────────────
function initUsers() {
  let u = DB.get('users');
  if (!u.length) {
    u = [{ id: 'admin', nom: 'Administrateur', login: 'admin', mdp: 'admin2025', role: 'admin', ville: 'Kinshasa', statut: 'actif' }];
    DB.set('users', u);
  }
  return u;
}

// ──────────────────────────────────────────
// CONNEXION / DÉCONNEXION
// ──────────────────────────────────────────
function doLogin() {
  const login = v('loginUser');
  const mdp = v('loginPass');
  const users = initUsers();
  const user = users.find(u => u.login === login && u.mdp === mdp && u.statut === 'actif');
  if (!user) { show('loginError'); return; }
  hide('loginError');
  CU = user;
  g('loginPage').style.display = 'none';
  g('app').classList.remove('hidden');
  applySession();
  initApp();
}

function doLogout() {
  CU = null;
  g('app').classList.add('hidden');
  g('loginPage').style.display = '';
  g('loginUser').value = '';
  g('loginPass').value = '';
}

function applySession() {
  const nm = CU.nom;
  g('sbUserName').textContent = nm;
  g('sbUserRole').textContent = CU.role.charAt(0).toUpperCase() + CU.role.slice(1);
  g('sbAvatar').textContent = nm.charAt(0).toUpperCase();
  g('tucAvatar').textContent = nm.charAt(0).toUpperCase();
  g('tucName').textContent = nm;
  // masquer éléments admin
  document.querySelectorAll('.admin-only').forEach(el => {
    el.style.display = CU.role === 'admin' ? '' : 'none';
  });
}

function togglePwd() {
  const inp = g('loginPass');
  const ico = g('eyeIcon');
  if (inp.type === 'password') { inp.type = 'text'; ico.className = 'fas fa-eye-slash'; }
  else { inp.type = 'password'; ico.className = 'fas fa-eye'; }
}

// ──────────────────────────────────────────
// INIT APPLICATION
// ──────────────────────────────────────────
function initApp() {
  g('loginYear').textContent = new Date().getFullYear();
  updateClock();
  setInterval(updateClock, 1000);
  loadConfig();
  applyBranding();
  renderAll();
  showModule('dashboard');
}

function updateClock() {
  if (g('tbClock')) {
    const n = new Date();
    g('tbClock').textContent = n.toLocaleDateString('fr-FR', { weekday: 'short', day: '2-digit', month: 'short' }) +
      ' ' + n.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  }
}

function renderAll() {
  renderClients(); renderCommerciaux(); renderTargets();
  renderDevis(); renderFactures(); renderMarchands();
  renderCommissions(); renderProduits(); renderDepenses();
  renderTreso(); renderUsers(); populateSelects();
}

// ──────────────────────────────────────────
// NAVIGATION
// ──────────────────────────────────────────
const LABELS = {
  dashboard: 'Tableau de bord', crm: 'Clients CRM', commerciaux: 'Commerciaux',
  targets: 'Objectifs / Targets', devis: 'Gestion des Devis', factures: 'Gestion des Factures',
  marchands: 'Suivi Marchands Pdirect', commissions: 'Commissions Pdirect',
  produits: 'Produits', depenses: 'Dépenses', tresorerie: 'Trésorerie',
  parametres: 'Paramètres société', admin: 'Gestion utilisateurs'
};

function showModule(name) {
  document.querySelectorAll('.module').forEach(m => m.classList.remove('active'));
  document.querySelectorAll('.sb-link').forEach(l => l.classList.remove('active'));
  const mod = g('mod-' + name);
  if (mod) mod.classList.add('active');
  document.querySelectorAll(`.sb-link[data-mod="${name}"]`).forEach(l => l.classList.add('active'));
  g('breadcrumb').textContent = LABELS[name] || name;

  if (name === 'dashboard') updateDashboard();
  if (name === 'depenses') updateDepKPIs();
  if (name === 'tresorerie') updateTresoKPIs();
  if (name === 'parametres') { loadConfigForm(); updateInvoicePreview(); }

  // mobile: close sidebar
  g('sidebar').classList.remove('mobile-open');
}

function toggleSidebar() {
  const sb = g('sidebar');
  const mc = g('mainContent');
  if (window.innerWidth <= 900) {
    sb.classList.toggle('mobile-open');
  } else {
    sb.classList.toggle('collapsed');
    mc.classList.toggle('expanded');
  }
}

// ──────────────────────────────────────────
// MODALS
// ──────────────────────────────────────────
function openModal(id) {
  const m = g(id);
  if (!m) return;
  m.classList.add('open');
  // Reset hidden ids
  m.querySelectorAll('input[type=hidden]').forEach(el => el.value = '');
  m.querySelectorAll('input:not([type=hidden]):not([readonly]), select, textarea').forEach(el => el.value = el.tagName === 'SELECT' ? el.options[0]?.value || '' : '');
  if (id === 'mDevis') { resetLines('dv'); g('dvNum').value = genNum(CFG.prefDevis || 'DV'); g('dvTvaLbl').textContent = CFG.tva; g('dvDate').value = today(); }
  if (id === 'mFacture') { resetLines('fa'); g('faNum').value = genNum(CFG.prefFact || 'FA'); g('faTvaLbl').textContent = CFG.tva; g('faDate').value = today(); }
  populateSelects();
}
function closeModal(id) { g(id).classList.remove('open'); }

// close on backdrop click
document.addEventListener('click', e => { if (e.target.classList.contains('modal-bg')) e.target.classList.remove('open'); });
document.addEventListener('keydown', e => { if (e.key === 'Enter' && g('loginPage').style.display !== 'none') doLogin(); });

// ──────────────────────────────────────────
// UTILITAIRES
// ──────────────────────────────────────────
const g = id => document.getElementById(id);
const v = id => g(id)?.value?.trim() || '';
const show = id => g(id)?.classList.remove('hidden');
const hide = id => g(id)?.classList.add('hidden');
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const today = () => new Date().toISOString().split('T')[0];
const fmtDate = d => d ? new Date(d).toLocaleDateString('fr-FR') : '—';
const fmt = n => parseFloat(n || 0).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ' + CFG.devise;

function genNum(prefix) {
  const yr = new Date().getFullYear();
  const r = String(Math.floor(Math.random() * 900) + 100);
  return `${prefix}-${yr}-${r}`;
}

function toast(msg, type = 'ok') {
  const t = g('toast');
  t.textContent = (type === 'ok' ? '✓  ' : '⚠  ') + msg;
  t.className = 'toast ' + type;
  t.classList.remove('hidden');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.add('hidden'), 3200);
}

function filterTbl(tblId, srcId) {
  const q = g(srcId).value.toLowerCase();
  document.querySelectorAll('#' + tblId + ' tbody tr').forEach(row => {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

function badge(status) {
  const map = {
    actif: 'bg-green', active: 'bg-green', 'en cours': 'bg-sky', installé: 'bg-blue',
    inactif: 'bg-grey', suspendu: 'bg-red', désinstallé: 'bg-grey',
    prospect: 'bg-sky', payée: 'bg-green', 'non payée': 'bg-red',
    partiel: 'bg-orange', brouillon: 'bg-grey', envoyé: 'bg-sky',
    accepté: 'bg-green', refusé: 'bg-red', 'en attente': 'bg-orange',
    admin: 'bg-red', commercial: 'bg-blue', comptable: 'bg-orange',
    atteint: 'bg-green', 'en retard': 'bg-red'
  };
  return `<span class="badge ${map[(status || '').toLowerCase()] || 'bg-grey'}">${status || '—'}</span>`;
}

// ──────────────────────────────────────────
// SELECTS DYNAMIQUES
// ──────────────────────────────────────────
function populateSelects() {
  const comms = DB.get('commerciaux');
  const clients = DB.get('clients');
  const marchs = DB.get('marchands');

  fillSelect(['cCommercial', 'tCommercial', 'mrCommercial', 'coCommercial', 'faCommercial'],
    comms, c => ({ val: c.nom, lbl: c.nom }));
  fillSelect(['dvClient', 'faClient'], clients, c => ({ val: c.nom, lbl: c.nom }));
  fillSelect(['coMarchand'], marchs, m => ({ val: m.nom, lbl: m.nom }));
}

function fillSelect(ids, data, mapper) {
  ids.forEach(id => {
    const sel = g(id);
    if (!sel) return;
    const cur = sel.value;
    sel.innerHTML = '<option value="">— Sélectionner —</option>';
    data.forEach(item => {
      const { val, lbl } = mapper(item);
      sel.innerHTML += `<option value="${val}" ${cur === val ? 'selected' : ''}>${lbl}</option>`;
    });
  });
}

// ──────────────────────────────────────────
// DASHBOARD
// ──────────────────────────────────────────
function updateDashboard() {
  const clients = DB.get('clients');
  const factures = DB.get('factures');
  const marchs = DB.get('marchands');
  const comms = DB.get('commerciaux');
  const treso = DB.get('treso');

  const ca = factures.filter(f => f.statut === 'payée').reduce((s, f) => s + (+f.total || 0), 0);
  const entrees = treso.filter(t => t.type === 'entrée').reduce((s, t) => s + (+t.montant || 0), 0);
  const sorties = treso.filter(t => t.type === 'sortie').reduce((s, t) => s + (+t.montant || 0), 0);
  const solde = entrees - sorties;

  g('kpiClients').textContent = clients.length;
  g('kpiFactures').textContent = factures.length;
  g('kpiMarchands').textContent = marchs.length;
  g('kpiCA').textContent = fmt(ca);
  g('kpiComm').textContent = comms.filter(c => c.statut === 'actif').length;
  g('kpiSolde').textContent = fmt(solde);
  g('dashDate').textContent = new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });

  renderActivities();
  renderDashTargets();
}

function renderActivities() {
  const all = [];
  const lbls = { clients: 'Nouveau client', factures: 'Facture créée', devis: 'Devis créé', marchands: 'Marchand ajouté' };
  const cols = { clients: 'b', factures: 'g', devis: 'b', marchands: 'r' };
  ['clients', 'factures', 'devis', 'marchands'].forEach(k => {
    DB.get(k).forEach(item => all.push({ k, label: item.nom || item.num || '—', date: item.created || item.date || '' }));
  });
  all.sort((a, b) => new Date(b.date) - new Date(a.date));
  const c = g('recentAct');
  c.innerHTML = all.length ? all.slice(0, 8).map(a => `
    <div class="act-item">
      <div class="act-dot ${cols[a.k]}"></div>
      <div>
        <div class="act-text"><strong>${lbls[a.k]}</strong>: ${a.label}</div>
        <div class="act-time">${fmtDate(a.date)}</div>
      </div>
    </div>`).join('') : '<div class="empty"><i class="fas fa-inbox"></i><p>Aucune activité</p></div>';
}

function renderDashTargets() {
  const targets = DB.get('targets');
  const c = g('dashTargets');
  c.innerHTML = targets.length ? targets.slice(0, 5).map(t => {
    const pct = t.objectif > 0 ? Math.min(100, Math.round((+t.realise / +t.objectif) * 100)) : 0;
    const col = pct >= 100 ? 'g' : pct >= 50 ? 'b' : 'r';
    return `<div class="tgt-item">
      <div class="tgt-meta">
        <span class="tgt-name">${t.commercial} — ${t.type}</span>
        <span class="tgt-pct" style="color:var(--${col === 'g' ? 'blue-d' : col === 'r' ? 'red' : 'blue'})">${pct}%</span>
      </div>
      <div class="prog-wrap"><div class="prog ${col}" style="width:${pct}%"></div></div>
      <div style="font-size:.7rem;color:var(--txt-m);margin-top:.25rem">${t.periode} — ${t.realise}/${t.objectif} ${t.type === "Chiffre d'affaires" ? CFG.devise : ''}</div>
    </div>`;
  }).join('') : '<div class="empty"><i class="fas fa-bullseye"></i><p>Aucun objectif</p></div>';
}

// ──────────────────────────────────────────
// CLIENTS
// ──────────────────────────────────────────
function saveClient() {
  const id = v('cId');
  const data = {
    id: id || uid(), nom: v('cNom'), email: v('cEmail'), tel: v('cTel'),
    ville: v('cVille'), statut: v('cStatut'), commercial: v('cCommercial'),
    adresse: v('cAdresse'), notes: v('cNotes'), created: new Date().toISOString()
  };
  if (!data.nom) { toast('Nom obligatoire', 'err'); return; }
  let list = DB.get('clients');
  list = id ? list.map(x => x.id === id ? data : x) : [...list, data];
  DB.set('clients', list);
  closeModal('mClient'); renderClients(); toast('Client enregistré');
}

function renderClients() {
  const flt = v('fltClientStatut');
  let list = DB.get('clients');
  if (flt) list = list.filter(c => c.statut === flt);
  const b = g('bodyClients');
  b.innerHTML = list.length ? list.map((c, i) => `<tr>
    <td>${i + 1}</td><td><strong>${c.nom}</strong></td><td>${c.email || '—'}</td>
    <td>${c.tel || '—'}</td><td>${c.ville || '—'}</td>
    <td>${badge(c.statut)}</td><td>${c.commercial || '—'}</td>
    <td><button class="btn-icon btn-edit" onclick="editClient('${c.id}')"><i class="fas fa-edit"></i></button>
    <button class="btn-icon btn-del" onclick="del('clients','${c.id}',renderClients)"><i class="fas fa-trash"></i></button></td>
  </tr>`).join('') : emptyRow(8);
}

function editClient(id) {
  const c = DB.get('clients').find(x => x.id === id); if (!c) return;
  openModal('mClient');
  g('cId').value = c.id; g('cNom').value = c.nom; g('cEmail').value = c.email;
  g('cTel').value = c.tel; g('cVille').value = c.ville; g('cStatut').value = c.statut;
  setTimeout(() => { g('cCommercial').value = c.commercial; }, 50);
  g('cAdresse').value = c.adresse || ''; g('cNotes').value = c.notes || '';
}

// ──────────────────────────────────────────
// COMMERCIAUX
// ──────────────────────────────────────────
function saveCommercial() {
  const id = v('commId');
  const mdp = v('commMdp'); const mdp2 = v('commMdp2');
  if (!id && mdp !== mdp2) { toast('Les mots de passe ne correspondent pas', 'err'); return; }
  const data = {
    id: id || uid(), nom: v('commNom'), login: v('commLogin'), mdp: mdp || '—',
    email: v('commEmail'), tel: v('commTel'), ville: v('commVille'), zone: v('commZone'),
    statut: v('commStatut')
  };
  if (!data.nom || !data.login) { toast('Nom et login obligatoires', 'err'); return; }
  let list = DB.get('commerciaux');
  if (!id && list.find(c => c.login === data.login)) { toast('Login déjà utilisé', 'err'); return; }
  list = id ? list.map(x => x.id === id ? { ...x, ...data } : x) : [...list, data];
  DB.set('commerciaux', list);
  // Sync users
  let users = DB.get('users');
  if (!id && !users.find(u => u.login === data.login)) {
    users.push({ id: uid(), nom: data.nom, login: data.login, mdp: data.mdp, role: 'commercial', ville: data.ville, statut: 'actif' });
    DB.set('users', users);
  }
  closeModal('mCommercial'); renderCommerciaux(); renderUsers(); populateSelects();
  toast('Commercial enregistré');
}

function renderCommerciaux() {
  const list = DB.get('commerciaux');
  const b = g('bodyComm');
  b.innerHTML = list.length ? list.map((c, i) => `<tr>
    <td>${i + 1}</td><td><strong>${c.nom}</strong></td>
    <td><code style="background:#EEF2F7;padding:.1rem .4rem;border-radius:4px">${c.login}</code></td>
    <td>${c.email || '—'}</td><td>${c.tel || '—'}</td>
    <td>${c.ville || '—'} ${c.zone ? '/ ' + c.zone : ''}</td>
    <td>${badge(c.statut)}</td>
    <td><button class="btn-icon btn-edit" onclick="editComm('${c.id}')"><i class="fas fa-edit"></i></button>
    <button class="btn-icon btn-del" onclick="del('commerciaux','${c.id}',renderCommerciaux)"><i class="fas fa-trash"></i></button></td>
  </tr>`).join('') : emptyRow(8);
}

function editComm(id) {
  const c = DB.get('commerciaux').find(x => x.id === id); if (!c) return;
  openModal('mCommercial');
  g('commId').value = c.id; g('commNom').value = c.nom; g('commLogin').value = c.login;
  g('commMdp').value = c.mdp; g('commMdp2').value = c.mdp;
  g('commEmail').value = c.email; g('commTel').value = c.tel;
  g('commVille').value = c.ville; g('commZone').value = c.zone; g('commStatut').value = c.statut;
}

// ──────────────────────────────────────────
// TARGETS
// ──────────────────────────────────────────
function saveTarget() {
  const id = v('tId');
  const data = {
    id: id || uid(), commercial: v('tCommercial'), periode: v('tPeriode'),
    type: v('tType'), objectif: +v('tObjectif'), realise: +v('tRealise')
  };
  if (!data.commercial || !data.periode) { toast('Commercial et période obligatoires', 'err'); return; }
  let list = DB.get('targets');
  list = id ? list.map(x => x.id === id ? data : x) : [...list, data];
  DB.set('targets', list); closeModal('mTarget'); renderTargets(); toast('Objectif enregistré');
}

function renderTargets() {
  const list = DB.get('targets');
  const b = g('bodyTargets');
  b.innerHTML = list.length ? list.map((t, i) => {
    const pct = t.objectif > 0 ? Math.min(100, Math.round((+t.realise / +t.objectif) * 100)) : 0;
    const col = pct >= 100 ? 'g' : pct >= 50 ? 'b' : 'r';
    const s = pct >= 100 ? 'Atteint' : pct >= 50 ? 'En cours' : 'En retard';
    return `<tr>
      <td>${i + 1}</td><td>${t.commercial}</td><td>${t.periode}</td><td>${t.type}</td>
      <td>${t.objectif}</td><td>${t.realise}</td>
      <td><div class="prog-wrap"><div class="prog ${col}" style="width:${pct}%"></div></div><small>${pct}%</small></td>
      <td>${badge(s)}</td>
      <td><button class="btn-icon btn-edit" onclick="editTarget('${t.id}')"><i class="fas fa-edit"></i></button>
      <button class="btn-icon btn-del" onclick="del('targets','${t.id}',renderTargets)"><i class="fas fa-trash"></i></button></td>
    </tr>`;
  }).join('') : emptyRow(9);
}

function editTarget(id) {
  const t = DB.get('targets').find(x => x.id === id); if (!t) return;
  openModal('mTarget');
  g('tId').value = t.id; g('tPeriode').value = t.periode;
  g('tType').value = t.type; g('tObjectif').value = t.objectif; g('tRealise').value = t.realise;
  setTimeout(() => g('tCommercial').value = t.commercial, 50);
}

// ──────────────────────────────────────────
// LIGNES DEVIS / FACTURE
// ──────────────────────────────────────────
let lineCnt = { dv: 0, fa: 0 };

function resetLines(ctx) {
  lineCnt[ctx] = 0;
  const c = g(ctx + 'Lines');
  const hdr = c.querySelector('.lines-head');
  c.innerHTML = ''; c.appendChild(hdr);
  calcTotaux(ctx);
}

function addLine(ctx) {
  lineCnt[ctx]++;
  const lid = `${ctx}l${lineCnt[ctx]}`;
  const c = g(ctx + 'Lines');
  const d = document.createElement('div');
  d.className = 'inv-line'; d.id = lid;
  d.innerHTML = `
    <input type="text" placeholder="Désignation du produit/service" oninput="calcLine('${lid}','${ctx}')"/>
    <input type="number" value="1" min="0" step="any" oninput="calcLine('${lid}','${ctx}')"/>
    <input type="number" value="0" min="0" step="0.01" oninput="calcLine('${lid}','${ctx}')"/>
    <span class="lt">0.00 ${CFG.devise}</span>
    <button class="btn-rm" onclick="document.getElementById('${lid}').remove();calcTotaux('${ctx}')"><i class="fas fa-times"></i></button>`;
  c.appendChild(d);
}

function calcLine(lid, ctx) {
  const el = g(lid); if (!el) return;
  const nums = el.querySelectorAll('input[type=number]');
  const tot = (+nums[0].value || 0) * (+nums[1].value || 0);
  el.querySelector('.lt').textContent = tot.toFixed(2) + ' ' + CFG.devise;
  calcTotaux(ctx);
}

function calcTotaux(ctx) {
  let ht = 0;
  g(ctx + 'Lines').querySelectorAll('.inv-line').forEach(el => {
    const n = el.querySelectorAll('input[type=number]');
    ht += (+n[0]?.value || 0) * (+n[1]?.value || 0);
  });
  const tva = ht * (CFG.tva / 100);
  const ttc = ht + tva;
  g(ctx + 'HT').textContent = ht.toFixed(2) + ' ' + CFG.devise;
  g(ctx + 'TVA').textContent = tva.toFixed(2) + ' ' + CFG.devise;
  g(ctx + 'TTC').textContent = ttc.toFixed(2) + ' ' + CFG.devise;
  return { ht, tva, ttc };
}

function getLines(ctx) {
  const lines = [];
  g(ctx + 'Lines').querySelectorAll('.inv-line').forEach(el => {
    const inputs = el.querySelectorAll('input');
    const nums = el.querySelectorAll('input[type=number]');
    lines.push({ desig: inputs[0]?.value || '', qty: +nums[0]?.value || 0, pu: +nums[1]?.value || 0, total: (+nums[0]?.value || 0) * (+nums[1]?.value || 0) });
  });
  return lines;
}

// ──────────────────────────────────────────
// DEVIS
// ──────────────────────────────────────────
function saveDevis() {
  const id = v('dvId');
  const tot = calcTotaux('dv');
  const data = {
    id: id || uid(), num: v('dvNum'), client: v('dvClient'),
    date: v('dvDate'), validite: v('dvValidite'), statut: v('dvStatut'),
    ht: tot.ht, tva: tot.tva, total: tot.ttc, lines: getLines('dv'),
    created: new Date().toISOString()
  };
  if (!data.client || !data.date) { toast('Client et date obligatoires', 'err'); return; }
  let list = DB.get('devis');
  list = id ? list.map(x => x.id === id ? data : x) : [...list, data];
  DB.set('devis', list); closeModal('mDevis'); renderDevis(); toast('Devis enregistré');
}

function renderDevis() {
  const list = DB.get('devis');
  const b = g('bodyDevis');
  b.innerHTML = list.length ? list.map((d, i) => `<tr>
    <td>${i + 1}</td><td><strong>${d.num}</strong></td><td>${d.client}</td>
    <td>${fmtDate(d.date)}</td><td>${fmtDate(d.validite)}</td>
    <td><strong>${fmt(d.total)}</strong></td><td>${badge(d.statut)}</td>
    <td>
      <button class="btn-icon btn-conv" title="Convertir en facture" onclick="convertToFacture('${d.id}')"><i class="fas fa-file-invoice"></i></button>
      <button class="btn-icon btn-del" onclick="del('devis','${d.id}',renderDevis)"><i class="fas fa-trash"></i></button>
    </td>
  </tr>`).join('') : emptyRow(8);
}

function convertToFacture(id) {
  const d = DB.get('devis').find(x => x.id === id); if (!d) return;
  openModal('mFacture');
  setTimeout(() => {
    g('faClient').value = d.client;
    g('faDate').value = today();
    resetLines('fa');
    (d.lines || []).forEach(ln => {
      addLine('fa');
      const last = g('faLines').querySelectorAll('.inv-line');
      const el = last[last.length - 1];
      if (el) {
        const inputs = el.querySelectorAll('input');
        const nums = el.querySelectorAll('input[type=number]');
        if (inputs[0]) inputs[0].value = ln.desig;
        if (nums[0]) nums[0].value = ln.qty;
        if (nums[1]) nums[1].value = ln.pu;
        calcLine(el.id, 'fa');
      }
    });
    toast('Devis converti en facture — vérifiez et enregistrez');
  }, 100);
}

// ──────────────────────────────────────────
// FACTURES
// ──────────────────────────────────────────
function saveFacture() {
  const id = v('faId');
  const tot = calcTotaux('fa');
  const data = {
    id: id || uid(), num: v('faNum'), client: v('faClient'),
    date: v('faDate'), echeance: v('faEcheance'), statut: v('faStatut'),
    commercial: v('faCommercial'), ht: tot.ht, tva: tot.tva, total: tot.ttc,
    lines: getLines('fa'), created: new Date().toISOString()
  };
  if (!data.client || !data.date) { toast('Client et date obligatoires', 'err'); return; }
  let list = DB.get('factures');
  list = id ? list.map(x => x.id === id ? data : x) : [...list, data];
  DB.set('factures', list); closeModal('mFacture'); renderFactures(); toast('Facture enregistrée');
}

function renderFactures() {
  const list = DB.get('factures');
  const b = g('bodyFactures');
  b.innerHTML = list.length ? list.map((f, i) => `<tr>
    <td>${i + 1}</td><td><strong>${f.num}</strong></td><td>${f.client}</td>
    <td>${fmtDate(f.date)}</td><td>${fmtDate(f.echeance)}</td>
    <td><strong>${fmt(f.total)}</strong></td><td>${badge(f.statut)}</td>
    <td>
      <button class="btn-icon btn-print" title="Imprimer" onclick="printFact('${f.id}')"><i class="fas fa-print"></i></button>
      <button class="btn-icon btn-del" onclick="del('factures','${f.id}',renderFactures)"><i class="fas fa-trash"></i></button>
    </td>
  </tr>`).join('') : emptyRow(8);
}

function printDoc(ctx) { if (ctx === 'facture') printFact(null, true); }

function printFact(id, fromModal = false) {
  let f;
  if (fromModal) {
    // Construire à partir du modal ouvert
    const tot = calcTotaux('fa');
    f = {
      num: v('faNum'), client: v('faClient'), date: v('faDate'),
      echeance: v('faEcheance'), statut: v('faStatut'),
      ht: tot.ht, tva: tot.tva, total: tot.ttc, lines: getLines('fa')
    };
  } else {
    f = DB.get('factures').find(x => x.id === id);
  }
  if (!f) return;
  const logoHtml = CFG.logo
    ? `<img class="ph-logo-img" src="${CFG.logo}" alt="Logo"/>`
    : `<i class="fas fa-mobile-alt ph-logo-icon"></i>`;
  const linesHtml = (f.lines || []).filter(l => l.desig).map(l =>
    `<tr><td>${l.desig}</td><td style="text-align:center">${l.qty}</td><td style="text-align:right">${l.pu.toFixed(2)}</td><td style="text-align:right;font-weight:700">${l.total.toFixed(2)}</td></tr>`
  ).join('');
  const bankInfo = (CFG.banque || CFG.compte || CFG.momo) ? `
    <div class="bank-info">
      <strong>Coordonnées bancaires / Paiement:</strong><br/>
      ${CFG.banque ? 'Banque: ' + CFG.banque + ' | ' : ''}
      ${CFG.titulaire ? 'Titulaire: ' + CFG.titulaire + ' | ' : ''}
      ${CFG.compte ? 'Compte: ' + CFG.compte + ' | ' : ''}
      ${CFG.swift ? 'SWIFT: ' + CFG.swift + ' | ' : ''}
      ${CFG.momo ? 'Mobile Money: ' + CFG.momo : ''}
    </div>` : '';
  g('printZone').innerHTML = `
    <div class="ph">
      <div class="ph-logo-area">
        <div class="ipv-logo">${logoHtml}</div>
        <div>
          <div class="ph-comp-name">${CFG.nom}</div>
          <div class="ph-comp-detail">${CFG.adresse || ''} ${CFG.ville || ''} ${CFG.pays || ''}</div>
          <div class="ph-comp-detail">${CFG.tel1 ? 'Tél: ' + CFG.tel1 : ''} ${CFG.email ? '| ' + CFG.email : ''}</div>
          ${CFG.rccm ? '<div class="ph-comp-detail">RCCM: ' + CFG.rccm + (CFG.nif ? ' | NIF: ' + CFG.nif : '') + '</div>' : ''}
        </div>
      </div>
      <div class="ph-right">
        <div class="ph-doc-type">FACTURE</div>
        <div class="ph-doc-meta"><strong>N°:</strong> ${f.num}</div>
        <div class="ph-doc-meta"><strong>Date:</strong> ${fmtDate(f.date)}</div>
        <div class="ph-doc-meta"><strong>Échéance:</strong> ${fmtDate(f.echeance)}</div>
        <div class="ph-doc-meta">${badge(f.statut)}</div>
      </div>
    </div>
    <div class="client-info"><strong>Facturé à :</strong>${f.client}</div>
    <table class="pt">
      <thead><tr><th>Désignation</th><th style="text-align:center">Qté</th><th style="text-align:right">P.U. (${CFG.devise})</th><th style="text-align:right">Total (${CFG.devise})</th></tr></thead>
      <tbody>${linesHtml}</tbody>
    </table>
    <div class="tot-section">
      <div>Sous-total HT : <strong>${f.ht.toFixed(2)} ${CFG.devise}</strong></div>
      <div>TVA (${CFG.tva}%) : <strong>${f.tva.toFixed(2)} ${CFG.devise}</strong></div>
      <div class="grand">TOTAL TTC : ${f.total.toFixed(2)} ${CFG.devise}</div>
    </div>
    ${bankInfo}
    ${CFG.mention ? '<div class="mention">' + CFG.mention + '</div>' : ''}
    <div class="mention" style="text-align:center;margin-top:1rem">Merci pour votre confiance — ${CFG.nom}</div>
  `;
  setTimeout(() => window.print(), 150);
}

// ──────────────────────────────────────────
// MARCHANDS
// ──────────────────────────────────────────
function saveMarchand() {
  const id = v('mrId');
  const data = {
    id: id || uid(), nom: v('mrNom'), tel: v('mrTel'), secteur: v('mrSecteur'),
    ville: v('mrVille'), commercial: v('mrCommercial'), date: v('mrDate'),
    pdirectId: v('mrPdirectId'), statut: v('mrStatut'), notes: v('mrNotes'),
    created: new Date().toISOString()
  };
  if (!data.nom) { toast('Nom obligatoire', 'err'); return; }
  let list = DB.get('marchands');
  list = id ? list.map(x => x.id === id ? data : x) : [...list, data];
  DB.set('marchands', list); closeModal('mMarchand'); renderMarchands(); populateSelects();
  toast('Marchand enregistré');
}

function renderMarchands() {
  const list = DB.get('marchands');
  const b = g('bodyMarchands');
  b.innerHTML = list.length ? list.map((m, i) => `<tr>
    <td>${i + 1}</td><td><strong>${m.nom}</strong></td><td>${m.tel || '—'}</td>
    <td>${m.secteur || '—'}</td><td>${m.ville || '—'}</td><td>${m.commercial || '—'}</td>
    <td>${fmtDate(m.date)}</td>
    <td><code style="background:#EEF2F7;padding:.1rem .4rem;border-radius:4px;font-size:.8rem">${m.pdirectId || '—'}</code></td>
    <td>${badge(m.statut)}</td>
    <td><button class="btn-icon btn-edit" onclick="editMarchand('${m.id}')"><i class="fas fa-edit"></i></button>
    <button class="btn-icon btn-del" onclick="del('marchands','${m.id}',renderMarchands)"><i class="fas fa-trash"></i></button></td>
  </tr>`).join('') : emptyRow(10);
}

function editMarchand(id) {
  const m = DB.get('marchands').find(x => x.id === id); if (!m) return;
  openModal('mMarchand');
  g('mrId').value = m.id; g('mrNom').value = m.nom; g('mrTel').value = m.tel;
  g('mrSecteur').value = m.secteur; g('mrVille').value = m.ville;
  g('mrDate').value = m.date; g('mrPdirectId').value = m.pdirectId;
  g('mrStatut').value = m.statut; g('mrNotes').value = m.notes || '';
  setTimeout(() => g('mrCommercial').value = m.commercial, 50);
}

// ──────────────────────────────────────────
// COMMISSIONS
// ──────────────────────────────────────────
function calcComm() {
  const vol = +v('coVolume') || 0;
  const taux = +v('coTaux') || 0;
  g('coMontant').value = (vol * taux / 100).toFixed(2);
}

function saveCommission() {
  const id = v('coId');
  calcComm();
  const data = {
    id: id || uid(), marchand: v('coMarchand'), periode: v('coPeriode'),
    volume: +v('coVolume'), taux: +v('coTaux'), montant: +v('coMontant'),
    commercial: v('coCommercial'), statut: v('coStatut')
  };
  if (!data.marchand || !data.periode) { toast('Marchand et période obligatoires', 'err'); return; }
  let list = DB.get('commissions');
  list = id ? list.map(x => x.id === id ? data : x) : [...list, data];
  DB.set('commissions', list); closeModal('mCommission'); renderCommissions(); toast('Commission enregistrée');
}

function renderCommissions() {
  const list = DB.get('commissions');
  const b = g('bodyCommissions');
  b.innerHTML = list.length ? list.map((c, i) => `<tr>
    <td>${i + 1}</td><td><strong>${c.marchand}</strong></td><td>${c.periode}</td>
    <td>${fmt(c.volume)}</td><td>${c.taux}%</td>
    <td><strong>${fmt(c.montant)}</strong></td><td>${c.commercial || '—'}</td>
    <td>${badge(c.statut)}</td>
    <td><button class="btn-icon btn-edit" onclick="editComm2('${c.id}')"><i class="fas fa-edit"></i></button>
    <button class="btn-icon btn-del" onclick="del('commissions','${c.id}',renderCommissions)"><i class="fas fa-trash"></i></button></td>
  </tr>`).join('') : emptyRow(9);
}

function editComm2(id) {
  const c = DB.get('commissions').find(x => x.id === id); if (!c) return;
  openModal('mCommission');
  g('coId').value = c.id; g('coPeriode').value = c.periode;
  g('coVolume').value = c.volume; g('coTaux').value = c.taux;
  g('coMontant').value = c.montant; g('coStatut').value = c.statut;
  setTimeout(() => { g('coMarchand').value = c.marchand; g('coCommercial').value = c.commercial; }, 50);
}

// ──────────────────────────────────────────
// PRODUITS
// ──────────────────────────────────────────
function saveProduit() {
  const id = v('prId');
  const data = {
    id: id || uid(), ref: v('prRef'), nom: v('prNom'), categorie: v('prCat'),
    prix: +v('prPrix'), stock: +v('prStock'), unite: v('prUnite'), desc: v('prDesc')
  };
  if (!data.nom) { toast('Nom obligatoire', 'err'); return; }
  let list = DB.get('produits');
  list = id ? list.map(x => x.id === id ? data : x) : [...list, data];
  DB.set('produits', list); closeModal('mProduit'); renderProduits(); toast('Produit enregistré');
}

function renderProduits() {
  const list = DB.get('produits');
  const b = g('bodyProduits');
  b.innerHTML = list.length ? list.map((p, i) => `<tr>
    <td>${i + 1}</td>
    <td><code style="background:#EEF2F7;padding:.1rem .4rem;border-radius:4px">${p.ref || '—'}</code></td>
    <td><strong>${p.nom}</strong></td><td>${p.categorie || '—'}</td>
    <td><strong>${fmt(p.prix)}</strong></td>
    <td><span class="${p.stock <= 0 ? 'badge bg-red' : 'badge bg-green'}">${p.stock}</span></td>
    <td>${p.unite}</td>
    <td><button class="btn-icon btn-edit" onclick="editProd('${p.id}')"><i class="fas fa-edit"></i></button>
    <button class="btn-icon btn-del" onclick="del('produits','${p.id}',renderProduits)"><i class="fas fa-trash"></i></button></td>
  </tr>`).join('') : emptyRow(8);
}

function editProd(id) {
  const p = DB.get('produits').find(x => x.id === id); if (!p) return;
  openModal('mProduit');
  g('prId').value = p.id; g('prRef').value = p.ref; g('prNom').value = p.nom;
  g('prCat').value = p.categorie; g('prPrix').value = p.prix;
  g('prStock').value = p.stock; g('prUnite').value = p.unite; g('prDesc').value = p.desc;
}

// ──────────────────────────────────────────
// DÉPENSES
// ──────────────────────────────────────────
function saveDepense() {
  const id = v('deId');
  const data = {
    id: id || uid(), date: v('deDate'), libelle: v('deLibelle'),
    categorie: v('deCat'), montant: +v('deMontant'),
    payePar: v('dePayePar'), justif: v('deJustif')
  };
  if (!data.libelle || !data.date) { toast('Libellé et date obligatoires', 'err'); return; }
  let list = DB.get('depenses');
  list = id ? list.map(x => x.id === id ? data : x) : [...list, data];
  DB.set('depenses', list); closeModal('mDepense'); renderDepenses(); updateDepKPIs();
  toast('Dépense enregistrée');
}

function renderDepenses() {
  const list = DB.get('depenses').sort((a, b) => new Date(b.date) - new Date(a.date));
  const b = g('bodyDepenses');
  b.innerHTML = list.length ? list.map((d, i) => `<tr>
    <td>${i + 1}</td><td>${fmtDate(d.date)}</td><td><strong>${d.libelle}</strong></td>
    <td><span class="badge bg-sky">${d.categorie}</span></td>
    <td><strong style="color:var(--red)">${fmt(d.montant)}</strong></td>
    <td>${d.payePar || '—'}</td><td>${d.justif || '—'}</td>
    <td><button class="btn-icon btn-edit" onclick="editDep('${d.id}')"><i class="fas fa-edit"></i></button>
    <button class="btn-icon btn-del" onclick="del('depenses','${d.id}',renderDepenses)"><i class="fas fa-trash"></i></button></td>
  </tr>`).join('') : emptyRow(8);
}

function editDep(id) {
  const d = DB.get('depenses').find(x => x.id === id); if (!d) return;
  openModal('mDepense');
  g('deId').value = d.id; g('deDate').value = d.date; g('deLibelle').value = d.libelle;
  g('deCat').value = d.categorie; g('deMontant').value = d.montant;
  g('dePayePar').value = d.payePar; g('deJustif').value = d.justif;
}

function updateDepKPIs() {
  const list = DB.get('depenses');
  const now = new Date(); const todayStr = today();
  const m = now.getMonth(), y = now.getFullYear();
  const jour = list.filter(d => d.date === todayStr).reduce((s, d) => s + (+d.montant || 0), 0);
  const mois = list.filter(d => { const dd = new Date(d.date); return dd.getMonth() === m && dd.getFullYear() === y; }).reduce((s, d) => s + (+d.montant || 0), 0);
  const an = list.filter(d => new Date(d.date).getFullYear() === y).reduce((s, d) => s + (+d.montant || 0), 0);
  g('depJour').textContent = fmt(jour);
  g('depMois').textContent = fmt(mois);
  g('depAn').textContent = fmt(an);
}

// ──────────────────────────────────────────
// TRÉSORERIE
// ──────────────────────────────────────────
function saveTreso() {
  const id = v('trId');
  const data = {
    id: id || uid(), date: v('trDate'), libelle: v('trLibelle'),
    type: v('trType'), montant: +v('trMontant'), compte: v('trCompte'), ref: v('trRef')
  };
  if (!data.libelle || !data.date) { toast('Libellé et date obligatoires', 'err'); return; }
  let list = DB.get('treso');
  list = id ? list.map(x => x.id === id ? data : x) : [...list, data];
  DB.set('treso', list); closeModal('mTreso'); renderTreso(); updateTresoKPIs();
  toast('Mouvement enregistré');
}

function renderTreso() {
  const list = DB.get('treso').sort((a, b) => new Date(b.date) - new Date(a.date));
  const b = g('bodyTreso');
  b.innerHTML = list.length ? list.map((t, i) => {
    const isIn = t.type === 'entrée';
    return `<tr>
      <td>${i + 1}</td><td>${fmtDate(t.date)}</td><td><strong>${t.libelle}</strong></td>
      <td>${isIn ? '<span class="badge bg-green">↓ Entrée</span>' : '<span class="badge bg-red">↑ Sortie</span>'}</td>
      <td><strong style="color:${isIn ? 'var(--blue)' : 'var(--red)'}">${isIn ? '+' : '−'}${fmt(t.montant)}</strong></td>
      <td>${t.compte}</td><td>${t.ref || '—'}</td>
      <td><button class="btn-icon btn-edit" onclick="editTreso('${t.id}')"><i class="fas fa-edit"></i></button>
      <button class="btn-icon btn-del" onclick="del('treso','${t.id}',renderTreso)"><i class="fas fa-trash"></i></button></td>
    </tr>`;
  }).join('') : emptyRow(8);
}

function editTreso(id) {
  const t = DB.get('treso').find(x => x.id === id); if (!t) return;
  openModal('mTreso');
  g('trId').value = t.id; g('trDate').value = t.date; g('trLibelle').value = t.libelle;
  g('trType').value = t.type; g('trMontant').value = t.montant; g('trCompte').value = t.compte; g('trRef').value = t.ref;
}

function updateTresoKPIs() {
  const list = DB.get('treso');
  const inn = list.filter(t => t.type === 'entrée').reduce((s, t) => s + (+t.montant || 0), 0);
  const out = list.filter(t => t.type === 'sortie').reduce((s, t) => s + (+t.montant || 0), 0);
  const sol = inn - out;
  g('tresoIn').textContent = fmt(inn);
  g('tresoOut').textContent = fmt(out);
  g('tresoSolde').textContent = fmt(sol);
  const c = g('soldCard');
  c.className = 'kpi-card ' + (sol >= 0 ? 'blue' : 'red');
}

// ──────────────────────────────────────────
// UTILISATEURS
// ──────────────────────────────────────────
function saveUser() {
  const id = v('uId');
  const data = {
    id: id || uid(), nom: v('uNom'), login: v('uLogin'), mdp: v('uMdp'),
    role: v('uRole'), ville: v('uVille'), statut: v('uStatut')
  };
  if (!data.nom || !data.login || !data.mdp) { toast('Nom, login et mot de passe obligatoires', 'err'); return; }
  let list = DB.get('users');
  if (!id && list.find(u => u.login === data.login)) { toast('Login déjà utilisé', 'err'); return; }
  list = id ? list.map(u => u.id === id ? { ...u, ...data } : u) : [...list, data];
  DB.set('users', list); closeModal('mUser'); renderUsers(); toast('Utilisateur enregistré');
}

function renderUsers() {
  const list = DB.get('users');
  const b = g('bodyUsers');
  b.innerHTML = list.length ? list.map((u, i) => `<tr>
    <td>${i + 1}</td><td><strong>${u.nom}</strong></td>
    <td><code style="background:#EEF2F7;padding:.1rem .4rem;border-radius:4px">${u.login}</code></td>
    <td>${badge(u.role)}</td><td>${u.ville || '—'}</td><td>${badge(u.statut)}</td>
    <td>${u.login !== 'admin' ? `<button class="btn-icon btn-del" onclick="delUser('${u.id}')"><i class="fas fa-trash"></i></button>` : '<span style="font-size:.7rem;color:var(--txt-m)">Protégé</span>'}</td>
  </tr>`).join('') : '';
}

function delUser(id) {
  if (!confirm('Supprimer cet utilisateur ?')) return;
  DB.set('users', DB.get('users').filter(u => u.id !== id));
  renderUsers(); toast('Utilisateur supprimé', 'err');
}

// ──────────────────────────────────────────
// PARAMÈTRES SOCIÉTÉ + LOGO
// ──────────────────────────────────────────
function loadConfig() {
  CFG = DB.getObj('config', CFG);
}

function loadConfigForm() {
  const fields = ['Nom','Sigle','Secteur','Rccm','Nif','Adresse','Ville','Pays',
    'Tel1','Tel2','Email','Web','Devise','Tva','PrefFact','PrefDevis','Delai',
    'Mention','Banque','Titulaire','Compte','Swift','Momo'];
  fields.forEach(f => {
    const el = g('p' + f);
    if (el) el.value = CFG[f.charAt(0).toLowerCase() + f.slice(1)] || '';
  });
  // Logo
  if (CFG.logo) {
    g('logoPreviewImg').src = CFG.logo;
    g('logoPreviewImg').classList.remove('hidden');
    g('luzPreview').style.display = 'none';
    g('logoActions').style.display = 'flex';
  }
  updateInvoicePreview();
}

function saveParams() {
  CFG = {
    nom: v('pNom') || CFG.nom, sigle: v('pSigle'), secteur: v('pSecteur'),
    rccm: v('pRccm'), nif: v('pNif'), adresse: v('pAdresse'), ville: v('pVille'),
    pays: v('pPays'), tel1: v('pTel1'), tel2: v('pTel2'), email: v('pEmail'),
    web: v('pWeb'), devise: v('pDevise') || '$',
    tva: parseFloat(v('pTva')) || 16, prefFact: v('pPrefFact') || 'FA',
    prefDevis: v('pPrefDevis') || 'DV', delai: +v('pDelai') || 30,
    mention: v('pMention'), banque: v('pBanque'), titulaire: v('pTitulaire'),
    compte: v('pCompte'), swift: v('pSwift'), momo: v('pMomo'),
    logo: CFG.logo || ''
  };
  DB.setObj('config', CFG);
  applyBranding();
  updateInvoicePreview();
  const msg = g('paramsSavedMsg');
  msg.classList.remove('hidden');
  setTimeout(() => msg.classList.add('hidden'), 3000);
  toast('Paramètres enregistrés');
}

function applyBranding() {
  // Sidebar name
  const nm = CFG.sigle || CFG.nom?.substring(0, 4).toUpperCase() || 'MMSG';
  const sbName = g('sbName');
  if (sbName) sbName.textContent = nm;

  // Login brand
  const lbMain = g('loginBrandName');
  const lbSub = g('loginBrandSub');
  if (lbMain) lbMain.textContent = nm;
  if (lbSub) lbSub.textContent = CFG.nom || 'Mobile Marketing Solutions Group';

  // Logo in sidebar
  const sbLogoImg = g('sbLogoImg');
  const sbDefaultIcon = g('sbDefaultIcon');
  const loginIcon = document.querySelector('.login-default-icon');

  if (CFG.logo) {
    if (sbLogoImg) { sbLogoImg.src = CFG.logo; sbLogoImg.classList.remove('hidden'); }
    if (sbDefaultIcon) sbDefaultIcon.classList.add('hidden');
    if (loginIcon) { loginIcon.innerHTML = `<img src="${CFG.logo}" style="max-width:90%;max-height:90%;object-fit:contain;border-radius:6px"/>`; }
  } else {
    if (sbLogoImg) sbLogoImg.classList.add('hidden');
    if (sbDefaultIcon) sbDefaultIcon.classList.remove('hidden');
    if (loginIcon) loginIcon.innerHTML = '<i class="fas fa-mobile-alt"></i>';
  }
}

function updateInvoicePreview() {
  const ipvLogo = g('ipvLogo');
  const ipvName = g('ipvName');
  const ipvDetail = g('ipvDetail');
  const ipvContact = g('ipvContact');
  const ipvDate = g('ipvDate');
  if (ipvName) ipvName.textContent = CFG.nom || 'Mobile Marketing Solutions Group';
  if (ipvDetail) ipvDetail.textContent = [CFG.adresse, CFG.ville, CFG.pays].filter(Boolean).join(' — ') || 'Adresse — Ville, Pays';
  if (ipvContact) ipvContact.textContent = [CFG.tel1 ? 'Tél: ' + CFG.tel1 : '', CFG.email ? 'Email: ' + CFG.email : ''].filter(Boolean).join(' | ') || 'Tél: — Email: —';
  if (ipvDate) ipvDate.textContent = new Date().toLocaleDateString('fr-FR');
  if (ipvLogo) {
    ipvLogo.innerHTML = CFG.logo
      ? `<img src="${CFG.logo}" style="max-width:100%;max-height:100%;object-fit:contain;border-radius:6px"/>`
      : '<i class="fas fa-mobile-alt" style="font-size:2.5rem;color:var(--red)"></i>';
  }
}

// ── UPLOAD LOGO ──
function handleLogoUpload(event) {
  const file = event.target.files[0];
  if (file) processLogoFile(file);
}

function handleLogoDrop(event) {
  event.preventDefault();
  const file = event.dataTransfer.files[0];
  if (file && file.type.startsWith('image/')) processLogoFile(file);
}

function processLogoFile(file) {
  if (file.size > 2 * 1024 * 1024) { toast('Logo trop volumineux (max 2 Mo)', 'err'); return; }
  const reader = new FileReader();
  reader.onload = (e) => {
    CFG.logo = e.target.result;
    DB.setObj('config', CFG);
    const img = g('logoPreviewImg');
    img.src = CFG.logo;
    img.classList.remove('hidden');
    g('luzPreview').style.display = 'none';
    g('logoActions').style.display = 'flex';
    applyBranding();
    updateInvoicePreview();
    toast('Logo chargé avec succès');
  };
  reader.readAsDataURL(file);
}

function removeLogo() {
  if (!confirm('Supprimer le logo ?')) return;
  CFG.logo = '';
  DB.setObj('config', CFG);
  g('logoPreviewImg').classList.add('hidden');
  g('logoPreviewImg').src = '';
  g('luzPreview').style.display = '';
  g('logoActions').style.display = 'none';
  g('logoFileInput').value = '';
  applyBranding();
  updateInvoicePreview();
  toast('Logo supprimé');
}

// Drag-over styling
document.addEventListener('DOMContentLoaded', () => {
  const zone = g('logoZone');
  if (zone) {
    zone.addEventListener('dragover', () => zone.classList.add('drag-over'));
    zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
    zone.addEventListener('drop', () => zone.classList.remove('drag-over'));
  }
});

// ──────────────────────────────────────────
// SUPPRESSION GÉNÉRIQUE
// ──────────────────────────────────────────
function del(key, id, renderFn) {
  if (!confirm('Confirmer la suppression ?')) return;
  DB.set(key, DB.get(key).filter(x => x.id !== id));
  renderFn(); toast('Élément supprimé', 'err');
}

function emptyRow(cols) {
  return `<tr><td colspan="${cols}" style="text-align:center;color:var(--txt-m);padding:2.5rem;font-size:.85rem"><i class="fas fa-inbox" style="margin-right:.5rem;opacity:.3"></i>Aucun enregistrement</td></tr>`;
}

// ──────────────────────────────────────────
// INIT AU CHARGEMENT
// ──────────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  document.getElementById('loginYear').textContent = new Date().getFullYear();
  initUsers();
  loadConfig();
  applyBranding();
});
